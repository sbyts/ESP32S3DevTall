#include "ui_manager.h"
#include "../config/config.h"
#include "../system/sys_logger.h"
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>

UiManager uiManager;

// Software SPI constructor (CS, DC, MOSI, SCLK, RST) - bypasses ESP32-S3 hardware SPI peripherals
static Adafruit_GC9A01A tft(TFT_CS_PIN, TFT_DC_PIN, TFT_MOSI_PIN, TFT_SCLK_PIN, TFT_RST_PIN);

void UiManager::begin(LampState* statePtr) {
    _lampState = statePtr;

    LOG_I("Testing GC9A01 via Software SPI...");
    tft.begin();
    tft.setRotation(0);

    tft.fillScreen(GC9A01A_RED);
    delay(400);
    tft.fillScreen(GC9A01A_GREEN);
    delay(400);
    tft.fillScreen(GC9A01A_BLUE);
    delay(400);

    tft.fillScreen(GC9A01A_BLACK);
    tft.drawCircle(120, 120, 110, GC9A01A_CYAN);
    tft.setCursor(65, 115);
    tft.setTextColor(GC9A01A_WHITE);
    tft.setTextSize(2);
    tft.println("DISPLAY OK");

    LOG_I("Software SPI test complete");
}

void UiManager::update(float dt) {
    // Empty during hardware test
}