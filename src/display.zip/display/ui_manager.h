#ifndef UI_MANAGER_H
#define UI_MANAGER_H

#include <Arduino.h>
#include "../network/net_manager.h"

class UiManager {
public:
    void begin(LampState* statePtr);
    void update(float dt);

private:
    LampState* _lampState = nullptr;
    float _animBrightness = 0.0f;
    unsigned long _lastFrameMs = 0;

    void renderFrame();
};

extern UiManager uiManager;

#endif // UI_MANAGER_H