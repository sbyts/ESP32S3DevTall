#ifndef DISPLAY_LGFX_H
#define DISPLAY_LGFX_H

#include <LovyanGFX.hpp>
#include "../config/config.h"

class LGFX : public lgfx::LGFX_Device {
    lgfx::Panel_ST7789 _panel_instance;
    lgfx::Bus_SPI      _bus_instance;

public:
    LGFX(void) {
        {
            auto cfg = _bus_instance.config();
            cfg.spi_host    = SPI3_HOST;     // Dedicated GP-SPI3 controller for custom GPIO matrix pins
            cfg.spi_mode    = 3;
            cfg.freq_write  = 2000000;       // 2 MHz safe clock for long wires + 2k series resistors
            cfg.freq_read   = 2000000;
            cfg.spi_3wire   = false;         // Keep false when MISO is unconnected (-1)
            cfg.use_lock    = true;
            cfg.dma_channel = 0;             // Disable DMA for clean signal edges on long leads
            cfg.pin_sclk    = TFT_SCLK_PIN;  // Blue/Black (SCL) -> GPIO 12
            cfg.pin_mosi    = TFT_MOSI_PIN;  // Blue (SDA) -> GPIO 11
            cfg.pin_miso    = -1;
            cfg.pin_dc      = TFT_DC_PIN;    // Green (DC) -> GPIO 13

            _bus_instance.config(cfg);
            _panel_instance.setBus(&_bus_instance);
        }

        {
            auto cfg = _panel_instance.config();
            cfg.pin_cs           = TFT_CS_PIN;   // Yellow (CS) -> GPIO 10
            cfg.pin_rst          = TFT_RST_PIN;  // White (RST) -> GPIO 14
            cfg.pin_busy         = -1;
            cfg.panel_width      = TFT_WIDTH;
            cfg.panel_height     = TFT_HEIGHT;
            cfg.offset_x         = 0;
            cfg.offset_y         = 0;
            cfg.offset_rotation  = 0;
            cfg.dummy_read_pixel = 8;
            cfg.dummy_read_bits  = 1;
            cfg.readable         = false;
            cfg.invert           = true;         // GC9A01 IPS panel requires color inversion ON
            cfg.rgb_order        = false;
            cfg.dlen_16bit       = false;
            cfg.bus_shared       = false;

            _panel_instance.config(cfg);
        }

        setPanel(&_panel_instance);
    }
};

#endif // DISPLAY_LGFX_H